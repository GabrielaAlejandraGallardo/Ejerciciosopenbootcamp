# Facturacion_Tkinter
Aplicacion de facturacion de escritorion con python y tkinter

![Captura de pantalla de 2020-06-27 21-32-52](https://user-images.githubusercontent.com/56706251/85937122-c6b06480-b8bd-11ea-9678-38a293d0b3b8.png)

Una aplicacion de escritorio que realiza funciones de facturacion y reportes 

![Captura de pantalla de 2020-06-27 21-36-00](https://user-images.githubusercontent.com/56706251/85937183-58b86d00-b8be-11ea-9518-851e66c4117a.png)


